# Source-code selection notes

The uploaded working scripts were screened for open-source suitability. The following parts were **not** included:

1. Functions with hard-coded OpenAI credentials.
2. Scripts that depend on private absolute paths, unpublished Excel files, or local GPU configuration.
3. One-off exploratory plots and unrelated metaphor/image/grammar experiments.
4. Web scraping utilities and functions that would introduce unnecessary external dependencies.
5. Code relying on Python `eval()`; equivalent safe utilities use `ast.literal_eval()`.

The included modules preserve the reproducible workflow components described in the paper:

- preprocessing and table reshaping;
- domain-separated splitting;
- lexical-feature merging and split-aware surprisal;
- metadata permutation / CKA diagnostics;
- residual calibration;
- LLM prompting;
- LLM output parsing and evaluation.
